"use client"

import Link from "next/link"
import { useEffect, useRef, useState } from "react"
import {
  Heart,
  Menu,
  Search,
  ShoppingBag,
  UserRound,
  X,
  ArrowUpRight,
  Clock3,
  Command,
} from "lucide-react"
import { useCart } from "@/components/cart/cart-context"

const nav = [
  { label: "New In", href: "/new-in" },
  { label: "Women", href: "/women" },
  { label: "Men", href: "/men" },
  { label: "Kids", href: "/kids" },
  { label: "Collections", href: "/collections" },
  { label: "Luxury", href: "/products?category=Luxury" },
  { label: "Journal", href: "/journal" },
  { label: "Sale", href: "/sale" },
]

type SearchProduct = {
  id: string
  name: string
  slug: string
  price: number
  salePrice: number | null
  images: string[]
  category: string
}

const popularSearches = [
  "New arrivals",
  "Ready to Wear",
  "Luxury",
  "Unstitched",
  "Sale",
]

export function Header() {
  const { count, toggleCart } = useCart()

  const [mobileOpen, setMobileOpen] = useState(false)
  const [megaOpen, setMegaOpen] = useState(false)
  const [megaTab, setMegaTab] = useState("women")
  const [searchOpen, setSearchOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchProduct[]>([])
  const [loading, setLoading] = useState(false)
  const [recentSearches, setRecentSearches] = useState<string[]>([])
  const [activeIndex, setActiveIndex] = useState(-1)
  const [shortcutLabel, setShortcutLabel] = useState("Ctrl K")

  const inputRef = useRef<HTMLInputElement>(null)
  const megaCloseTimer = useRef<number | null>(null)

  const cancelMegaClose = () => {
    if (megaCloseTimer.current !== null) {
      window.clearTimeout(megaCloseTimer.current)
      megaCloseTimer.current = null
    }
  }

  const openMega = (tab: string) => {
    cancelMegaClose()
    setMegaTab(tab)
    setMegaOpen(true)
  }

  const scheduleMegaClose = () => {
    cancelMegaClose()
    megaCloseTimer.current = window.setTimeout(() => {
      setMegaOpen(false)
      megaCloseTimer.current = null
    }, 180)
  }

  useEffect(() => {
    return () => {
      if (megaCloseTimer.current !== null) {
        window.clearTimeout(megaCloseTimer.current)
      }
    }
  }, [])

  useEffect(() => {
    setShortcutLabel(
      /Mac|iPhone|iPad|iPod/i.test(navigator.platform) ? "⌘K" : "Ctrl K"
    )

    try {
      const stored = JSON.parse(
        localStorage.getItem("noore_recent_searches") || "[]"
      )

      if (Array.isArray(stored)) {
        setRecentSearches(
          stored
            .filter((v): v is string => typeof v === "string")
            .slice(0, 5)
        )
      }
    } catch {}
  }, [])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const isShortcut =
        (event.metaKey || event.ctrlKey) &&
        event.key.toLowerCase() === "k"

      if (isShortcut) {
        event.preventDefault()
        setSearchOpen(true)

        window.setTimeout(() => {
          inputRef.current?.focus()
        }, 0)
      }

      if (event.key === "Escape") {
        setSearchOpen(false)
        setMobileOpen(false)
      }

      if (!searchOpen || !results.length) return

      if (event.key === "ArrowDown") {
        event.preventDefault()
        setActiveIndex((index) =>
          Math.min(index + 1, results.length - 1)
        )
      }

      if (event.key === "ArrowUp") {
        event.preventDefault()
        setActiveIndex((index) => Math.max(index - 1, 0))
      }

      if (event.key === "Enter" && activeIndex >= 0) {
        event.preventDefault()

        const product = results[activeIndex]

        saveRecent(query)

        window.location.href = `/product/${product.slug}`
      }
    }

    window.addEventListener("keydown", onKeyDown)

    return () => {
      window.removeEventListener("keydown", onKeyDown)
    }
  }, [searchOpen, results, activeIndex, query])

  useEffect(() => {
    setActiveIndex(-1)
  }, [query])

  useEffect(() => {
    if (!searchOpen) return

    const q = query.trim()

    if (!q) {
      setResults([])
      setLoading(false)
      return
    }

    const controller = new AbortController()

    const timer = window.setTimeout(async () => {
      try {
        setLoading(true)

        const response = await fetch(
          `/api/search?q=${encodeURIComponent(q)}&take=8`,
          {
            signal: controller.signal,
          }
        )

        if (!response.ok) {
          throw new Error("Search failed")
        }

        const data = await response.json()

        setResults(
          Array.isArray(data.products) ? data.products : []
        )

        setActiveIndex(-1)
      } catch (error) {
        if ((error as Error).name !== "AbortError") {
          setResults([])
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false)
        }
      }
    }, 180)

    return () => {
      window.clearTimeout(timer)
      controller.abort()
    }
  }, [query, searchOpen])

  const saveRecent = (term: string) => {
    const value = term.trim()

    if (!value) return

    const next = [
      value,
      ...recentSearches.filter(
        (item) => item.toLowerCase() !== value.toLowerCase()
      ),
    ].slice(0, 5)

    setRecentSearches(next)

    try {
      localStorage.setItem(
        "noore_recent_searches",
        JSON.stringify(next)
      )
    } catch {}
  }

  const submitSearch = (event?: React.FormEvent) => {
    event?.preventDefault()

    const q = query.trim()

    if (!q) return

    saveRecent(q)

    window.location.href = `/search?q=${encodeURIComponent(q)}`
  }

  const chooseSuggestion = (value: string) => {
    setQuery(value)
    saveRecent(value)

    window.location.href = `/search?q=${encodeURIComponent(value)}`
  }

  return (
    <>
      {/* =========================================================
          DESKTOP / MOBILE HEADER
      ========================================================= */}
      <header className="sticky top-0 z-50 border-b border-black/5 bg-cream/95 text-charcoal backdrop-blur-xl">
        <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between px-4 sm:px-5">

          {/* MOBILE MENU BUTTON */}
          <button
            type="button"
            className="relative z-[60] mr-3 grid h-10 w-10 shrink-0 place-items-center rounded-full border border-black/10 bg-white/90 transition hover:bg-white md:hidden"
            onClick={() => {
              setMobileOpen(true)
              setMegaOpen(false)
            }}
            aria-label="Open navigation menu"
            aria-expanded={mobileOpen}
            aria-controls="noore-mobile-menu"
          >
            <Menu
              className="h-5 w-5"
              strokeWidth={1.8}
            />
          </button>

          {/* LOGO */}
          <Link
            href="/"
            className="font-editorial text-[28px] font-semibold tracking-tight"
          >
            NOORÉ
          </Link>

          {/* DESKTOP NAVIGATION */}
          <nav
            className="hidden items-center gap-5 md:flex"
            onMouseEnter={cancelMegaClose}
            onMouseLeave={scheduleMegaClose}
          >
            <Link
              href="/products"
              className="nav-link"
              onMouseEnter={() => openMega("all")}
              onFocus={() => openMega("all")}
            >
              Shop All
            </Link>

            {[
              ["Women", "/women", "women"],
              ["Men", "/men", "men"],
              ["Kids", "/kids", "kids"],
              ["Collections", "/collections", "collections"],
            ].map(([label, href, tab]) => (
              <div key={label} className="relative">
                <Link
                  href={href}
                  className="nav-link inline-flex items-center gap-1"
                  onMouseEnter={() => openMega(tab)}
                  onFocus={() => openMega(tab)}
                >
                  {label}<span className="text-[9px]">⌄</span>
                </Link>
              </div>
            ))}

            <Link href="/products?category=Luxury" className="nav-link">Luxury</Link>
            <Link href="/blog" className="nav-link">Journal</Link>
            <Link href="/sale" className="nav-link">Sale</Link>
          </nav>

          {/* ACTIONS */}
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              type="button"
              onClick={() => {
                setSearchOpen(true)

                window.setTimeout(() => {
                  inputRef.current?.focus()
                }, 0)
              }}
              className="icon-button"
              aria-label="Search"
            >
              <Search className="h-[18px] w-[18px]" />

              <span className="absolute -bottom-0.5 left-1/2 hidden -translate-x-1/2 whitespace-nowrap text-[7px] text-secondary lg:block">
                {shortcutLabel}
              </span>
            </button>

            <Link
              href="/account"
              className="icon-button hidden sm:grid"
              aria-label="Account"
            >
              <UserRound className="h-[18px] w-[18px]" />
            </Link>

            <Link
              href="/wishlist"
              className="icon-button hidden sm:grid"
              aria-label="Wishlist"
            >
              <Heart className="h-[18px] w-[18px]" />
            </Link>

            <button
              type="button"
              onClick={toggleCart}
              className="icon-button relative"
              aria-label={`Shopping bag${
                count ? `, ${count} items` : ""
              }`}
            >
              <ShoppingBag className="h-[18px] w-[18px]" />

              {count > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-charcoal px-1 text-[9px] font-bold text-white">
                  {count > 99 ? "99+" : count}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* =========================================================
            SEARCH OVERLAY
        ========================================================= */}
        {searchOpen && (
          <div
            className="fixed inset-0 z-[9998] bg-charcoal/45 backdrop-blur-sm"
            onMouseDown={() => setSearchOpen(false)}
          >
            <div
              className="mx-auto mt-0 w-full max-w-3xl px-3 sm:px-5 md:mt-8"
              onMouseDown={(event) => event.stopPropagation()}
            >
              <div className="overflow-hidden rounded-2xl bg-white shadow-2xl">
                <form
                  onSubmit={submitSearch}
                  className="flex items-center gap-3 border-b border-black/10 px-4 py-3 sm:px-5"
                >
                  <Search className="h-5 w-5 shrink-0 text-secondary" />

                  <input
                    ref={inputRef}
                    autoFocus
                    value={query}
                    onChange={(event) =>
                      setQuery(event.target.value)
                    }
                    placeholder="Try ‘black cotton under 5000’…"
                    className="min-w-0 flex-1 bg-transparent py-3 text-base outline-none"
                    aria-label="Search NOORÉ"
                    aria-controls="noore-search-results"
                    aria-activedescendant={
                      activeIndex >= 0
                        ? `noore-result-${activeIndex}`
                        : undefined
                    }
                  />

                  <kbd className="hidden rounded-md border border-black/10 px-2 py-1 text-[10px] text-secondary sm:block">
                    ESC
                  </kbd>

                  <button
                    type="button"
                    onClick={() => setSearchOpen(false)}
                    className="rounded-full p-2 hover:bg-black/5"
                    aria-label="Close search"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </form>

                <div
                  id="noore-search-results"
                  className="max-h-[70vh] overflow-y-auto p-4 sm:p-5"
                >
                  {!query.trim() ? (
                    <div className="grid gap-6 sm:grid-cols-2">
                      <div>
                        <div className="mb-3 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.18em] text-secondary">
                          <Command className="h-3 w-3" />
                          Popular searches
                        </div>

                        <p className="mb-2 text-xs text-secondary">
                          Search naturally by product, fabric, color,
                          size or budget.
                        </p>

                        <div className="space-y-1">
                          {popularSearches.map((item) => (
                            <button
                              key={item}
                              type="button"
                              onClick={() =>
                                chooseSuggestion(item)
                              }
                              className="flex w-full items-center justify-between rounded-lg px-3 py-3 text-left text-sm hover:bg-cream"
                            >
                              <span>{item}</span>
                              <ArrowUpRight className="h-3.5 w-3.5 text-secondary" />
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="mb-3 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.18em] text-secondary">
                          <Clock3 className="h-3 w-3" />
                          Recent searches
                        </div>

                        {recentSearches.length ? (
                          <div className="space-y-1">
                            {recentSearches.map((item) => (
                              <button
                                key={item}
                                type="button"
                                onClick={() =>
                                  chooseSuggestion(item)
                                }
                                className="block w-full rounded-lg px-3 py-3 text-left text-sm hover:bg-cream"
                              >
                                {item}
                              </button>
                            ))}
                          </div>
                        ) : (
                          <p className="px-3 text-sm text-secondary">
                            Your recent searches will appear here.
                          </p>
                        )}
                      </div>
                    </div>
                  ) : loading ? (
                    <div className="py-12 text-center text-sm text-secondary">
                      Searching the NOORÉ collection…
                    </div>
                  ) : results.length ? (
                    <div>
                      <div className="mb-3 flex items-center justify-between">
                        <p className="text-[10px] font-semibold uppercase tracking-[.18em] text-secondary">
                          Products
                        </p>

                        <button
                          type="button"
                          onClick={() => submitSearch()}
                          className="text-[10px] font-semibold uppercase tracking-[.15em] underline underline-offset-4"
                        >
                          View all
                        </button>
                      </div>

                      <div className="grid gap-1">
                        {results.map((product, index) => (
                          <Link
                            key={product.id}
                            id={`noore-result-${index}`}
                            href={`/product/${product.slug}`}
                            onClick={() => {
                              saveRecent(query)
                              setSearchOpen(false)
                            }}
                            className={`group flex items-center gap-3 rounded-xl p-2 transition hover:bg-cream ${
                              activeIndex === index
                                ? "bg-cream"
                                : ""
                            }`}
                          >
                            <div className="h-16 w-14 shrink-0 overflow-hidden bg-cream">
                              {product.images?.[0] ? (
                                <img
                                  src={product.images[0]}
                                  alt=""
                                  className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                                />
                              ) : null}
                            </div>

                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium">
                                {product.name}
                              </p>

                              <p className="mt-1 text-[10px] uppercase tracking-[.12em] text-secondary">
                                {product.category}
                              </p>
                            </div>

                            <div className="text-right text-sm">
                              {product.salePrice != null ? (
                                <>
                                  <span className="block font-medium">
                                    PKR{" "}
                                    {product.salePrice.toLocaleString()}
                                  </span>

                                  <span className="text-xs text-secondary line-through">
                                    PKR{" "}
                                    {product.price.toLocaleString()}
                                  </span>
                                </>
                              ) : (
                                <span>
                                  PKR{" "}
                                  {product.price.toLocaleString()}
                                </span>
                              )}
                            </div>

                            <ArrowUpRight className="mr-1 h-4 w-4 text-secondary" />
                          </Link>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="py-12 text-center">
                      <Search className="mx-auto h-6 w-6 text-secondary" />

                      <p className="mt-3 font-editorial text-2xl">
                        No pieces found
                      </p>

                      <p className="mt-1 text-sm text-secondary">
                        Try a different product, category, fabric or SKU.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            PREMIUM DESKTOP MEGA MENU
        ========================================================= */}
        {megaOpen && (
          <div
            className="absolute left-0 right-0 top-full hidden border-t border-black/5 bg-white shadow-[0_24px_60px_rgba(0,0,0,.08)] md:block"
            onMouseEnter={cancelMegaClose}
            onMouseLeave={scheduleMegaClose}
          >
            <div className="mx-auto grid max-w-7xl grid-cols-[180px_1fr_280px] gap-8 px-5 py-8">
              <div className="border-r border-border pr-6">
                <p className="eyebrow">Shop the world</p>
                <div className="mt-4 space-y-1">
                  {[
                    ["all", "Shop All", "/products"],
                    ["women", "Women", "/women"],
                    ["men", "Men", "/men"],
                    ["kids", "Kids", "/kids"],
                    ["collections", "Collections", "/collections"],
                  ].map(([tab, label, href]) => (
                    <Link
                      key={tab}
                      href={href}
                      onMouseEnter={() => setMegaTab(tab)}
                      className={`flex items-center justify-between px-3 py-3 text-sm transition ${megaTab === tab ? "bg-cream font-medium" : "hover:bg-cream"}`}
                    >
                      {label}<ArrowUpRight className="h-3.5 w-3.5 text-secondary" />
                    </Link>
                  ))}
                </div>
              </div>

              <div>
                {megaTab === "all" && (
                  <>
                    <p className="eyebrow">Shop all / categories</p>
                    <div className="mt-5 grid grid-cols-3 gap-x-8 gap-y-3 text-sm">
                      <Link href="/new-in">New In</Link>
                      <Link href="/women">Women</Link>
                      <Link href="/men">Men</Link>
                      <Link href="/kids">Kids</Link>
                      <Link href="/collections">Collections</Link>
                      <Link href="/products?category=Luxury">Luxury</Link>
                      <Link href="/sale">Sale</Link>
                      <Link href="/journal">Journal</Link>
                      <Link href="/products">All Products</Link>
                    </div>
                  </>
                )}

                {megaTab === "women" && (
                  <>
                    <p className="eyebrow">Women / categories</p>
                    <div className="mt-5 grid grid-cols-3 gap-x-8 gap-y-3 text-sm">
                      <Link href="/products?gender=Women">All Women</Link>
                      <Link href="/products?gender=Women&category=Saree">Saree</Link>
                      <Link href="/products?gender=Women&category=Shalwar%20Kameez">Shalwar Kameez</Link>
                      <Link href="/products?gender=Women&category=2%20Piece">2 Piece</Link>
                      <Link href="/products?gender=Women&category=3%20Piece">3 Piece</Link>
                      <Link href="/products?gender=Women&category=Kurta">Kurta</Link>
                      <Link href="/products?gender=Women&category=Kurtis">Kurtis</Link>
                      <Link href="/products?gender=Women&category=Suits">Suits</Link>
                      <Link href="/products?gender=Women&category=Lawn">Lawn</Link>
                      <Link href="/products?gender=Women&category=Chiffon">Chiffon</Link>
                      <Link href="/products?gender=Women&category=Linen">Linen</Link>
                      <Link href="/products?gender=Women&category=Formal%20Wear">Formal Wear</Link>
                      <Link href="/products?gender=Women&category=Party%20Wear">Party Wear</Link>
                      <Link href="/products?gender=Women&category=Casual%20Wear">Casual Wear</Link>
                      <Link href="/products?gender=Women&category=Unstitched">Unstitched</Link>
                      <Link href="/products?gender=Women&category=Dupattas">Dupattas</Link>
                      <Link href="/products?gender=Women&category=Shawls">Shawls</Link>
                      <Link href="/products?gender=Women&category=Bottoms">Bottoms</Link>
                      <Link href="/products?gender=Women&sale=1">Sale</Link>
                    </div>
                  </>
                )}

                {megaTab === "men" && (
                  <>
                    <p className="eyebrow">Men / categories</p>
                    <div className="mt-5 grid grid-cols-3 gap-x-8 gap-y-3 text-sm">
                      <Link href="/products?gender=Men">All Men</Link>
                      <Link href="/products?gender=Men&category=Shalwar%20Kameez">Shalwar Kameez</Link>
                      <Link href="/products?gender=Men&category=Kurta">Kurta</Link>
                      <Link href="/products?gender=Men&category=2%20Piece">2 Piece</Link>
                      <Link href="/products?gender=Men&category=3%20Piece">3 Piece</Link>
                      <Link href="/products?gender=Men&category=Waistcoats">Waistcoats</Link>
                      <Link href="/products?gender=Men&category=Prince%20Coats">Prince Coats</Link>
                      <Link href="/products?gender=Men&category=Suits">Suits</Link>
                      <Link href="/products?gender=Men&category=Formal%20Wear">Formal Wear</Link>
                      <Link href="/products?gender=Men&category=Casual%20Wear">Casual Wear</Link>
                      <Link href="/products?gender=Men&category=Unstitched">Unstitched</Link>
                      <Link href="/products?gender=Men&category=Kameez">Kameez</Link>
                      <Link href="/products?gender=Men&category=Shalwar">Shalwar</Link>
                      <Link href="/products?gender=Men&category=Trousers">Trousers</Link>
                      <Link href="/products?gender=Men&category=Jackets">Jackets</Link>
                      <Link href="/products?gender=Men&category=Festive%20Wear">Festive Wear</Link>
                      <Link href="/products?gender=Men&sale=1">Sale</Link>
                    </div>
                  </>
                )}

                {megaTab === "kids" && (
                  <>
                    <p className="eyebrow">Kids / categories</p>
                    <div className="mt-5 grid grid-cols-3 gap-x-8 gap-y-3 text-sm">
                      <Link href="/products?gender=Kids">All Kids</Link>
                      <Link href="/products?gender=Kids&category=Girls%20Shalwar%20Kameez">Girls Shalwar Kameez</Link>
                      <Link href="/products?gender=Kids&category=Girls%202%20Piece">Girls 2 Piece</Link>
                      <Link href="/products?gender=Kids&category=Girls%203%20Piece">Girls 3 Piece</Link>
                      <Link href="/products?gender=Kids&category=Girls%20Kurtis">Girls Kurtis</Link>
                      <Link href="/products?gender=Kids&category=Girls%20Festive%20Wear">Girls Festive Wear</Link>
                      <Link href="/products?gender=Kids&category=Boys%20Shalwar%20Kameez">Boys Shalwar Kameez</Link>
                      <Link href="/products?gender=Kids&category=Boys%20Kurta">Boys Kurta</Link>
                      <Link href="/products?gender=Kids&category=Boys%20Waistcoats">Boys Waistcoats</Link>
                      <Link href="/products?gender=Kids&category=Boys%202%20Piece">Boys 2 Piece</Link>
                      <Link href="/products?gender=Kids&category=Girls%20Casual">Girls Casual</Link>
                      <Link href="/products?gender=Kids&category=Boys%20Casual">Boys Casual</Link>
                      <Link href="/products?gender=Kids&category=Formal">Formal</Link>
                      <Link href="/products?gender=Kids&category=Festive">Festive</Link>
                      <Link href="/products?gender=Kids&sale=1">Sale</Link>
                    </div>
                  </>
                )}

                {megaTab === "collections" && (
                  <>
                    <p className="eyebrow">Collections / stories</p>
                    <div className="mt-5 grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
                      <Link href="/collections">The New Edit</Link>
                      <Link href="/products?collection=Festive%202026">Festive 2026</Link>
                      <Link href="/products?collection=Modern%20Classics">Modern Classics</Link>
                      <Link href="/products?category=Luxury">The Evening Edit</Link>
                      <Link href="/products?collection=Lawn">Lawn & Summer</Link>
                      <Link href="/products?collection=Winter">Winter Edit</Link>
                      <Link href="/sale">Sale Edit</Link>
                      <Link href="/new-in">New Season</Link>
                    </div>
                  </>
                )}
              </div>

              <Link href={megaTab === "collections" ? "/collections" : megaTab === "all" ? "/products" : `/${megaTab}`} className="group relative min-h-[190px] overflow-hidden bg-charcoal text-white">
                <img src={megaTab === "women" ? "https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=900&auto=format&fit=crop" : megaTab === "men" ? "https://images.unsplash.com/photo-1617137968427-85924c800a22?w=900&auto=format&fit=crop" : megaTab === "kids" ? "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?w=900&auto=format&fit=crop" : "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=900&auto=format&fit=crop"} alt="" className="absolute inset-0 h-full w-full object-cover opacity-75 transition duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-black/35" />
                <div className="relative flex h-full min-h-[190px] flex-col justify-end p-5">
                  <p className="text-[9px] uppercase tracking-[.2em] text-white/65">NOORÉ / {megaTab === "all" ? "SHOP ALL" : megaTab}</p>
                  <p className="mt-2 font-editorial text-2xl">Discover the edit.</p>
                  <span className="mt-3 inline-flex items-center gap-2 text-[9px] font-semibold uppercase tracking-[.18em]">Explore <ArrowUpRight className="h-3 w-3" /></span>
                </div>
              </Link>
            </div>
          </div>
        )}

      </header>

      {/* =========================================================
          MOBILE MENU
          IMPORTANT: THIS IS OUTSIDE <header>
      ========================================================= */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-[9999] md:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="NOORÉ navigation"
        >
          {/* OVERLAY */}
          <button
            type="button"
            className="absolute inset-0 bg-black/55"
            onClick={() => setMobileOpen(false)}
            aria-label="Close navigation menu"
          />

          {/* DRAWER */}
          <aside
            id="noore-mobile-menu"
            className="absolute left-0 top-0 flex h-[100dvh] w-[88%] max-w-sm flex-col overflow-y-auto bg-cream text-charcoal shadow-2xl"
          >
            {/* DRAWER HEADER */}
            <div className="flex items-center justify-between border-b border-black/10 bg-cream px-5 py-5">
              <Link
                href="/"
                onClick={() => setMobileOpen(false)}
                className="font-editorial text-2xl font-semibold tracking-tight"
              >
                NOORÉ
              </Link>

              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                className="grid h-10 w-10 place-items-center rounded-full border border-black/10 bg-white"
                aria-label="Close navigation menu"
              >
                <X
                  className="h-5 w-5"
                  strokeWidth={1.8}
                />
              </button>
            </div>

            {/* DRAWER CONTENT */}
            <div className="px-5 pb-10">
              {/* SEARCH */}
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false)
                  setSearchOpen(true)

                  window.setTimeout(() => {
                    inputRef.current?.focus()
                  }, 100)
                }}
                className="mt-5 flex w-full items-center gap-3 border border-black/10 bg-white px-4 py-3.5 text-left text-sm"
              >
                <Search className="h-4 w-4 shrink-0 text-secondary" />

                <span>Search NOORÉ</span>

                <span className="ml-auto text-[10px] text-secondary">
                  {shortcutLabel}
                </span>
              </button>

              {/* NAVIGATION */}
              <nav
                className="mt-7"
                aria-label="Mobile navigation"
              >
                <Link
                  href="/products"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between border-b border-black/10 py-4 text-sm font-medium"
                >
                  <span>Shop All</span>

                  <ArrowUpRight className="h-4 w-4 text-secondary" />
                </Link>

                {nav.map((item) => (
                  <Link
                    key={item.label}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center justify-between border-b border-black/10 py-4 text-sm"
                  >
                    <span>{item.label}</span>

                    <ArrowUpRight className="h-4 w-4 text-secondary" />
                  </Link>
                ))}

                <Link
                  href="/account"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between border-b border-black/10 py-4 text-sm"
                >
                  <span>Account</span>

                  <UserRound className="h-4 w-4 text-secondary" />
                </Link>

                <Link
                  href="/wishlist"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between border-b border-black/10 py-4 text-sm"
                >
                  <span>Wishlist</span>

                  <Heart className="h-4 w-4 text-secondary" />
                </Link>

                <Link
                  href="/account/orders"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between border-b border-black/10 py-4 text-sm"
                >
                  <span>My Orders</span>

                  <ArrowUpRight className="h-4 w-4 text-secondary" />
                </Link>

                <Link
                  href="/blog"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between border-b border-black/10 py-4 text-sm"
                >
                  <span>Journal</span>

                  <ArrowUpRight className="h-4 w-4 text-secondary" />
                </Link>
              </nav>

              {/* HELP */}
              <div className="mt-8 bg-white p-5">
                <p className="eyebrow">
                  Need help?
                </p>

                <p className="mt-2 text-sm leading-6 text-secondary">
                  Our team is here for delivery, sizing and order questions.
                </p>
              </div>
            </div>
          </aside>
        </div>
      )}
    </>
  )
}